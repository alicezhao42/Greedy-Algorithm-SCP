package model;

import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import util.ElementSet; 

public class SCPModel {
	
	private TreeSet<ElementSet> _cover = new TreeSet<ElementSet>(); //treeSet of all the elementSets in the model (some numbers may be repeated within the elementsets) 
	private TreeSet<Integer> _elements = new TreeSet<Integer>(); //treeSet of all the integers in the SCP model with no repeats 
	
	public int getNumElementSets() {
		return _cover.size(); 
	}
	
	public int getNumElements() {
		return _elements.size(); 
	}
	
	public void addSetToCover(int i, double c, List<Integer> s) { 
		ElementSet _toAdd = new ElementSet(i, c, s); //create an elementSet with the given values 
		for (Integer _numbers : _toAdd.getElementIterable()) { //run through the integers of the elementSet lists  
			_elements.add(_numbers); //add the integer to my treeSet of all the integers 
		}
		_cover.add(_toAdd); //add the elementSet to cover 
	}
	
	public void addSetToCover(ElementSet _ele) {
		for (Integer _numbers : _ele.getElementIterable()) { //iterate through the elementSet lists 
			_elements.add(_numbers); //add the integers to my treeSet of all the integers 
		}
		_cover.add(_ele); //add the elementSet to cover 
	}
	
	public SortedSet<Integer> getElementsCopy() {
		return _elements; 
	}
	
	public Iterable<ElementSet> getElementSetiterable() {
		return _cover; 
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder(); 
		sb.append("\n" + "Weighted SCP model:" + "\n"); 
		sb.append("---------------------" + "\n"); 
		sb.append("Number of elements (n): " + _elements.size() + "\n"); 
		sb.append("Number of sets (m): " + _cover.size() + "\n" + "\n"); 
		sb.append("Set details:" + "\n" + "----------------------------------------------------------" + "\n"); 
		for (ElementSet s : _cover ) {
			sb.append(s + "\n"); 
		}
		return sb.toString(); 
	}
}
