package util;

import java.util.List;
import java.util.TreeSet;

public class ElementSet implements Comparable<ElementSet> {
	private int _id; 
	private double _cost; 
	private TreeSet<Integer> _intToCover; 

	public ElementSet(int id, double cost, List<Integer> intToCover) { //take in a int, double, and list
		_id = id; 
		_cost = cost; 
		_intToCover = new TreeSet<Integer>(intToCover);  //create a new treeSet with values of the list taken in 
	}

	@Override
	public int compareTo(ElementSet m) {
		int _diff = _id - m._id; 
		return _diff; //returns the difference between the id numbers (negative or positive) 
	}
	
	public boolean equals(ElementSet m) {
		boolean ifSame = false; //start off with ifSame as false so that it will become true when all 3 variables are the same
		if (this._cost == m._cost && this._intToCover.equals(m._intToCover) && this._id == m._id) { //return true only if cost, id number, and list is the same
			ifSame = true; 
		}
		return ifSame; 
	}
	
	public int getId() { //get the Set id number 
		return _id;
	}
	
	public double getCost() { //get the set cost 
		return _cost; 
	}
	
	public Iterable<Integer> getElementIterable() { //get the list of elements 
		return _intToCover; 
	}
	
	public double getNumElements() {
		return _intToCover.size(); //get the length of the list of values 
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder(); //create string builder 
		//sb.append("Set ID:");
		sb.append("Set ID: " + String.format("%3d",  _id)); 
		sb.append("   Cost: " + String.format("%6.2f", _cost)); //add cost 
		sb.append("   Element IDs: " + _intToCover); //add list of elements 
		return sb.toString(); //return as string 
	}

}
