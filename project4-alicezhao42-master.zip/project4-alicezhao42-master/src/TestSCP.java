import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import model.SCPModel;
import solver.ChvatalSolver;
import solver.GreedyCostSolver;
import solver.GreedyCoverageSolver;
import solver.GreedySolver;

import java.io.*;

/** Example testing class, identical to TestSCPSoln except for classes used.
 * 
 * @author ssanner@mie.utoronto.ca
 *
 */
public class TestSCP {
	
	public static BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String[] args) throws IOException {
		
		SCPModel model = new SCPModel();
		
		// Create a weighted SCP with
		//   Set 1: weight 3.0, elements { 1, 3, 5, 7, 9 }
		//   Set 2: weight 2.0, elements { 1, 5, 9 }
		//   Set 3: weight 2.0, elements { 5, 7, 9 }
		//   Set 4: weight 5.0, elements { 2, 4, 6, 8, 100 }
		//   Set 5: weight 2.0, elements { 2, 6, 100 }
		//   Set 6: weight 2.0, elements { 4, 8 }
		model.addSetToCover(6, 2.0, Arrays.asList(new Integer[] {4,8}));
		model.addSetToCover(5, 2.0, Arrays.asList(new Integer[] {2,6,100}));
		model.addSetToCover(4, 5.0, Arrays.asList(new Integer[] {2,4,6,8,100}));
		model.addSetToCover(3, 2.0, Arrays.asList(new Integer[] {5,7,9}));
		model.addSetToCover(2, 2.0, Arrays.asList(new Integer[] {1,5,9}));
		model.addSetToCover(1, 3.0, Arrays.asList(new Integer[] {1,3,5,7,9})); 
		model.addSetToCover(10, 4.0, Arrays.asList(new Integer[] {1,3,5,7,9}));
		model.addSetToCover(8, 3.0, Arrays.asList(new Integer[] {1,3,100,5,7,9})); 
		model.addSetToCover(9, 7.0, Arrays.asList(new Integer[] {1,3,100,5,7,9})); 
		model.addSetToCover(7, 3.0, Arrays.asList(new Integer[] {1,5}));
		model.addSetToCover(11, 5.0, Arrays.asList(new Integer[] {4,8,11,13}));
		model.addSetToCover(15, 17.0, Arrays.asList(new Integer[] {7,6,100,13,16,34,65}));
		model.addSetToCover(14, 1.0, Arrays.asList(new Integer[] {2,4,22,8,101,44,75}));
		model.addSetToCover(16, 21.0, Arrays.asList(new Integer[] {5,7,9}));
		model.addSetToCover(13, 4.0, Arrays.asList(new Integer[] {1,7,33,55,87,23}));
		model.addSetToCover(12, 9.0, Arrays.asList(new Integer[] {9})); 
		model.addSetToCover(20, 3.0, Arrays.asList(new Integer[] {1,3,5,7,9}));
		model.addSetToCover(18, 5.0, Arrays.asList(new Integer[] {1,17,5,7,9})); 
		model.addSetToCover(19, 7.0, Arrays.asList(new Integer[] {1,3,100,5,7,9})); 
		model.addSetToCover(17, 2.0, Arrays.asList(new Integer[] {1,5,22,86,43,33,12,76,88,39})); 
		
		model.addSetToCover(21, 2.0, Arrays.asList(new Integer[] {4,8,123,111,113,114,34}));
		model.addSetToCover(22, 25.0, Arrays.asList(new Integer[] {2,6,100,135,46,788,27,36}));
		model.addSetToCover(23, 51.0, Arrays.asList(new Integer[] {2,4,6,8,100,69,32,674,33,90,75}));
		model.addSetToCover(31, 22.0, Arrays.asList(new Integer[] {5,7,9,353,786,443,56,88,65,68,5}));
		model.addSetToCover(32, 20.0, Arrays.asList(new Integer[] {1,5,9,24,446,77,88,4,43,224,12}));
		model.addSetToCover(33, 3.0, Arrays.asList(new Integer[] {1,3,5,7,9,3554,566,867,48,64,3})); 
		model.addSetToCover(49, 4.0, Arrays.asList(new Integer[] {1,3}));
		model.addSetToCover(45, 10.0, Arrays.asList(new Integer[] {1,3,31,61,71})); 
		model.addSetToCover(44, 7.0, Arrays.asList(new Integer[] {1,3,100,67,57,47})); 
		model.addSetToCover(43, 33.0, Arrays.asList(new Integer[] {1,5,94,86,42}));
		model.addSetToCover(42, 5.0, Arrays.asList(new Integer[] {4,8,11,13}));
		model.addSetToCover(41, 17.0, Arrays.asList(new Integer[] {7,6,100,13,16,34,65}));
		model.addSetToCover(40, 13.0, Arrays.asList(new Integer[] {2,4,22,8,101,44,75}));
		model.addSetToCover(29, 217.0, Arrays.asList(new Integer[] {5,7,9}));
		model.addSetToCover(30, 43333.0, Arrays.asList(new Integer[] {1,7,33,55,87,23}));
		model.addSetToCover(28, 943.0, Arrays.asList(new Integer[] {9})); 
		model.addSetToCover(27, 343.0, Arrays.asList(new Integer[] {1,3,5,7,9,3,67,88,995,443,67,78,44,76,56}));
		model.addSetToCover(26, 522.0, Arrays.asList(new Integer[] {1,17,5,7,9,356,325,678,357})); 
		model.addSetToCover(25, 74.0, Arrays.asList(new Integer[] {1,3,100,5,7,9,24,566,88,4,677,3355,3566})); 
		model.addSetToCover(24, 27.0, Arrays.asList(new Integer[] {1,5,22,86,43})); 
		model.addSetToCover(64434, 27.0, Arrays.asList(new Integer[] {1,5,22,86,43})); 
		model.addSetToCover(252222222, 74.0, Arrays.asList(new Integer[] {1,3,100,5,7,9,24,566,88,4,677,3355,3566})); 
		model.addSetToCover(24, 27324324.0, Arrays.asList(new Integer[] {1,5,22,86,43})); 
		model.addSetToCover(64434333, 27222.0, Arrays.asList(new Integer[] {154,333,788,654,3453,342,65765,34543,67,5,22,86,43})); 
		
		model.addSetToCover(36, 2.0, Arrays.asList(new Integer[] {4,8}));
		model.addSetToCover(35, 2.0, Arrays.asList(new Integer[] {2,6,100}));
		model.addSetToCover(34, 5.0, Arrays.asList(new Integer[] {2,4,6,8,100}));
		model.addSetToCover(39, 2.0, Arrays.asList(new Integer[] {5,7,9}));
		model.addSetToCover(38, 2.0, Arrays.asList(new Integer[] {1,5,9}));
		model.addSetToCover(111, 3.0, Arrays.asList(new Integer[] {1,3,5,7,9})); 
		model.addSetToCover(102, 4.0, Arrays.asList(new Integer[] {1,32,5,7,9}));
		model.addSetToCover(83, 3.0, Arrays.asList(new Integer[] {1,3,100,5,7,9})); 
		model.addSetToCover(93, 7.0, Arrays.asList(new Integer[] {1,34,100,5,7,9})); 
		model.addSetToCover(73, 3.0, Arrays.asList(new Integer[] {1,566}));
		model.addSetToCover(141, 5.0, Arrays.asList(new Integer[] {4,877,11,13}));
		model.addSetToCover(165, 17.0, Arrays.asList(new Integer[] {7,68,100,13,16,34,65}));
		model.addSetToCover(184, 1.0, Arrays.asList(new Integer[] {2,488,22,8,101,44,75}));
		model.addSetToCover(156, 21.0, Arrays.asList(new Integer[] {5,799,9}));
		model.addSetToCover(103, 4.0, Arrays.asList(new Integer[] {1899,7,393,55,87,23}));
		model.addSetToCover(162, 9.0, Arrays.asList(new Integer[] {9,67})); 
		model.addSetToCover(260, 3.0, Arrays.asList(new Integer[] {1,3,5,7,9}));
		model.addSetToCover(168, 5.0, Arrays.asList(new Integer[] {1,17,5,7,9})); 
		model.addSetToCover(159, 7.0, Arrays.asList(new Integer[] {1,100,5,7,9})); 
		model.addSetToCover(157, 2.0, Arrays.asList(new Integer[] {1,5,22,86,43,33,12,76,88,39})); 
		
		model.addSetToCover(211, 2.0, Arrays.asList(new Integer[] {4,8,123,111,113,114,34}));
		model.addSetToCover(221, 25.0, Arrays.asList(new Integer[] {2,6,100,135,468,78,237,36}));
		model.addSetToCover(233, 51.0, Arrays.asList(new Integer[] {2,4,6,8,100,689,32,6734,33,90,75}));
		model.addSetToCover(313, 22.0, Arrays.asList(new Integer[] {5,7,4,353,786,43,56,883,635,638,35}));
		model.addSetToCover(323, 20.0, Arrays.asList(new Integer[] {1,5,9,284,77,88,4,43,224,12}));
		model.addSetToCover(333, 33.0, Arrays.asList(new Integer[] {1,3,55,7,9,3554,566,867,48,64,33})); 
		model.addSetToCover(493, 43.0, Arrays.asList(new Integer[] {1,3323}));
		model.addSetToCover(453, 130.0, Arrays.asList(new Integer[] {1,333,331,61,71})); 
		model.addSetToCover(443, 73.0, Arrays.asList(new Integer[] {1,3,1330,67,57,47,98,56,99,80})); 
		model.addSetToCover(433, 334.0, Arrays.asList(new Integer[] {1,5,944,86,42}));
		model.addSetToCover(423, 54.0, Arrays.asList(new Integer[] {4,8,141,13}));
		model.addSetToCover(413, 17.0, Arrays.asList(new Integer[] {7,6,100,13,16,34,65}));
		model.addSetToCover(406, 137.0, Arrays.asList(new Integer[] {2,4,222,8,101,44,75}));
		model.addSetToCover(296, 2197.0, Arrays.asList(new Integer[] {57,72,39}));
		model.addSetToCover(306, 4333.0, Arrays.asList(new Integer[] {19,73,33,55,87,23}));
		model.addSetToCover(286, 943.0, Arrays.asList(new Integer[] {9,23,65,335,667878,3})); 
		model.addSetToCover(276, 343.0, Arrays.asList(new Integer[] {1,3,5,77,9,3,67,88,995,57,443,67,78,44,76,56}));
		model.addSetToCover(266, 522.0, Arrays.asList(new Integer[] {1,17,5,7,749,5356,325,6,678,357})); 
		model.addSetToCover(258, 74.0, Arrays.asList(new Integer[] {1,3,100,5,47,9,24,566,88,4,23,677,3355,3566})); 
		model.addSetToCover(248, 27.0, Arrays.asList(new Integer[] {18,5,22,846,443})); 
		model.addSetToCover(64434, 27.0, Arrays.asList(new Integer[] {41,5,242,87,43})); 
		model.addSetToCover(252222222, 74.0, Arrays.asList(new Integer[] {16,38,100,5,7,9,24,566,88,4,677,3355,3566})); 
		model.addSetToCover(24, 27324324.0, Arrays.asList(new Integer[] {14,5,262,86,43})); 
		model.addSetToCover(64434333, 27222.0, Arrays.asList(new Integer[] {1554,333,788,654,3453,342,65765,34543,67,5,22,86,43}));
		
		model.addSetToCover(91, 343.6, Arrays.asList(new Integer[] {1,3,5,77,9,3,67,88,995,57,443,67,78,44,76,56}));
		model.addSetToCover(92, 522.3, Arrays.asList(new Integer[] {1,17,5,7,749,5356,325,6,678,357})); 
		model.addSetToCover(93, 75465644.4, Arrays.asList(new Integer[] {1,3,100,5,47,9,24,566,88,4,23,677,3355,3566})); 
		model.addSetToCover(82, 27.0, Arrays.asList(new Integer[] {18,846,443,45,34,67,55,88,99})); 
		model.addSetToCover(84, 27.0, Arrays.asList(new Integer[] {41,5,242,86,43,465,33,66,33,34})); 
		model.addSetToCover(2522222, 74.0, Arrays.asList(new Integer[] {196,398,1070,52,72,93,234,5656,883,434,67,3355,3566})); 
		model.addSetToCover(243254355, 27324324.0, Arrays.asList(new Integer[] {145,555,2562,856,453})); 
		model.addSetToCover(6443, 27222.0, Arrays.asList(new Integer[] {1344,363,7848,6544,34535,3742,6557655,3455453,677,75,722,876,473}));

		GreedyCoverageSolver CoverageMethod = new GreedyCoverageSolver();
		GreedyCostSolver CostMethod = new GreedyCostSolver();
		ChvatalSolver ChvatalMethod = new ChvatalSolver();
		
		List<GreedySolver> solvers = Arrays.asList(new GreedySolver[] {CoverageMethod, CostMethod, ChvatalMethod});
		
		printComparison(solvers, model, 0.5);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.3);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.9);
		
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.6);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.7);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.8);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 1.0);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 1.5);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.1);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.2);
		System.out.println("==========================================================================");
		printComparison(solvers, model, 0.3);
//		System.out.println("==========================================================================");
//		printComparison(solvers, model, 0.4);
//		System.out.println("==========================================================================");
//		printComparison(solvers, model, 6.0);
	}
		
	// set minimum coverage level for solution methods
	public static void printComparison(List<GreedySolver> solvers, SCPModel model, double alpha) {
			
		// Show the model
		System.out.println(model);
		
		// Run all solvers and record winners
		GreedySolver timeWinner = null;
		long minTime = Long.MAX_VALUE;
		
		GreedySolver objWinner = null;
		double minObj = Double.MAX_VALUE;
		
		GreedySolver covWinner = null;
		double maxCov = -Double.MAX_VALUE;
		
		for (GreedySolver s : solvers) {
			s.setMinCoverage(alpha);
			s.setModel(model);
			s.solve();
			s.print();
			s.printRowMetrics();
			
			if (minTime > s.getCompTime()) {
				minTime = s.getCompTime();
				timeWinner = s;
			}
			
			if (minObj > s.getObjFn()) {
				minObj = s.getObjFn();
				objWinner = s;
			}
			
			if (maxCov < s.getCoverage()) {
				maxCov = s.getCoverage();
				covWinner = s;
			}
		}

		System.out.format("\nAlpha: %.2f%%\n\n", 100*alpha);
		System.out.println("Algorithm                   Time (ms)     Obj Fn Val     Coverage (%)");
		System.out.println("---------------------------------------------------------------------");
		System.out.println("---------------------------------------------------------------------");
		for (GreedySolver s : solvers)
			s.printRowMetrics();
		System.out.format("%-25s%12s%15s%17s\n", "Category winner", timeWinner.getName(), objWinner.getName(), covWinner.getName());
		System.out.println("---------------------------------------------------------------------\n");
		
		String overall = "Unclear";
		if (timeWinner.getName().equals(objWinner.getName()) && 
			objWinner.getName().equals(covWinner.getName()))
			overall = timeWinner.getName();
		
		System.out.println("Overall winner: " + overall + "\n");
	}
	
}
