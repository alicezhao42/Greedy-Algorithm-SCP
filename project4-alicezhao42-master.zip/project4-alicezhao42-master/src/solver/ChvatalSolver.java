package solver;

import util.ElementSet;

public class ChvatalSolver extends GreedySolver {
	
	public ChvatalSolver() {
		_name = "Chvatal"; 
	}

	@Override
	public ElementSet nextBestSet() {
		double _ratio = Double.MAX_VALUE; 
		double _cov;  
		ElementSet _best = null; //set initial set as null
				
		for(ElementSet e: _model.getElementSetiterable()) { //run through all the elementSets in model 
			if (!_solnSets.contains(e)) { //continue checking this elementSet if it hasnt already been selected 
				_cov = 0; //reset the coverage for the next elementSet in the iteration 
				for(int i : e.getElementIterable()) { //run through all the integers in the elementSet list 
					if(!_solutionSet.contains(i)) { //add one to _cov if the list contains an integer that hasnt already been covered 
						_cov += 1;
					}
				} if((e.getCost() / _cov) < _ratio) { //if the ratio is higher than the initial ratio, make it the next best set
					_best = e;
					_ratio = e.getCost() / _cov; 
				}
			}
		}
	return _best; //return the best set 
	}
}
