package solver;

import java.util.TreeSet;

import model.SCPModel;
import util.ElementSet;

/** This is the main method that all solvers inherit from.  It is important
 *  to note how this solver calls nextBestSet() polymorphically!  Subclasses
 *  should *not* override solver(), they need only override nextBestSet().
 * 
 *  We'll assume models are well-defined here and do not specify Exceptions
 *  to throw.
 * 
 * @author ssanner@mie.utoronto.ca alicexiaoting.zhao@mail.utoronto.ca
 *
 */
public abstract class GreedySolver {
	
	protected String _name;			  // name of algorithm type
	protected double _alpha;          // minimum required coverage level in range [0,1]
	protected SCPModel _model;        // the SCP model we're currently operating on
	protected double _objFn;          // objective function value (*total cost sum* of all sets used)
	protected double _coverage;       // actual coverage fraction achieved
	protected long _compTime;         // computation time (ms)
	
	protected TreeSet<Integer> _solutionSet = new TreeSet<Integer>(); 
	protected TreeSet<ElementSet> _solnSets = new TreeSet<ElementSet>(); 
	
	// Basic setter (only one needed)
	public void setMinCoverage(double alpha) { _alpha = alpha; }
	public void setModel(SCPModel model) { _model = model; }
	
	// Basic getters
	public double getMinCoverage() { return _alpha; }
	public double getObjFn() { return _objFn; }
	public double getCoverage() { return _coverage; }
	public long getCompTime() { return _compTime; }
	public String getName() { return _name; }
		
	// TODO: Add any helper methods you need
	
	public int getNSetsSelected () { return _solnSets.size(); } 
	
	
	/** Run the simple greedy heuristic -- add the next best set until either
	 *  (1) The coverage level is reached, or 
	 *  (2) There is no set that can increase the coverage.
	 */
	public void solve() {
		
		// Reset the solver
		reset();
		
		// TODO: Preliminary initializations
		this._solutionSet = new TreeSet<Integer>(); 
		this._solnSets = new TreeSet<ElementSet>(); 
		int num_elements_not_covered = _model.getNumElements() - _solutionSet.size(); //elements not covered is the total number of elements minus the elements already covered 
		

		// Begin the greedy selection loop
		long start = System.currentTimeMillis();
		System.out.println("Running '" + getName() + "'...");

		// TODO: Fill in the main loop, pseudocode given below
		//
		// NOTE: In order to match the solution, pay attention to the following
		//       calculations (where you have to replace ALL-CAPS parts)
		//
		 int num_to_cover = (int)Math.ceil(_alpha * _model.getNumElements()); // number to cover is the percentage times the total number of elements 
		 int num_can_leave_uncovered = _model.getNumElements() - num_to_cover; //number that can be left uncovered is the total number of elements minus the number of elements to cover 

		 while (num_elements_not_covered > num_can_leave_uncovered && _solnSets.size() < _model.getNumElementSets()) {
			 ElementSet _nextBest = nextBestSet(); //create a variable to store the set returned by nextBestSet so it is only called once 
			 
			 if (_nextBest == null) {
				 System.out.println("- Selected: null");
				 break; 
			 }
			 
			 this._solnSets.add(_nextBest); //add the best set to the solution set 
			 for(int _toAdd: _nextBest.getElementIterable()) {
				 this._solutionSet.add(_toAdd); // add the integers of the next best set to the solution set 
			 }
			 _objFn += _nextBest.getCost(); //add the price of this set to the total cost 
			 num_elements_not_covered = _model.getNumElements() - _solutionSet.size(); //update the number of elements not covered 
			 System.out.println("- Selected: " + _nextBest); //print out the selected sets 
		 }
		 
		 
		 double s = _solutionSet.size();
				
		// Record final set coverage, compTime and print warning if applicable
		_coverage = s/_model.getNumElements(); 
		_compTime = System.currentTimeMillis() - start;
		
		if (_coverage < _alpha)
			System.out.format("\nWARNING: Impossible to reach %.2f%% coverage level.\n", 100*_alpha);
		System.out.println("Done.");
		
		
	}
	
	/** Returns the next best set to add to the solution according to the heuristic being used.
	 * 
	 *  NOTE 1: This is the **only** method to be implemented in child classes.
	 *  
	 *  NOTE 2: If no set can improve the solution, returns null to allow the greedy algorithm to terminate.
	 *  
	 *  NOTE 3: This references an ElementSet class which is a tuple of (Set ID, Cost, Integer elements to cover)
	 *          which you must define.
	 * 
	 * @return
	 */
	public abstract ElementSet nextBestSet(); // Abstract b/c it must be implemented by subclasses
	
	/** Print the solution
	 * 
	 */
	public void print() {
		System.out.println("\n'" + getName() + "' results:");
		System.out.format("'" + getName() + "'   Time to solve: %dms\n", _compTime);
		System.out.format("'" + getName() + "'   Objective function value: %.2f\n", _objFn);
		System.out.format("'" + getName() + "'   Coverage level: %.2f%% (%.2f%% minimum)\n", 100*_coverage, 100*_alpha);
		System.out.format("'" + getName() + "'   Number of sets selected: %d\n", _solnSets.size());
		System.out.format("'" + getName() + "'   Sets selected: ");
		for (ElementSet s : _solnSets) {
			System.out.print(s.getId() + " ");
		}
		System.out.println("\n");
	}
	
	/** Print the solution performance metrics as a row
	 * 
	 */
	public void printRowMetrics() {
		System.out.format("%-25s%12d%15.4f%17.2f\n", getName(), _compTime, _objFn, 100*_coverage);
	}	
	
	public void reset() { //clear all the treeSets containing solutions and all the applicable variables 
		_solutionSet.clear(); 
		_solnSets.clear(); 
		_coverage = 0; 
		_compTime = 0;
		_objFn = 0;
	}
	
	public boolean isSolved() {
		if (_coverage >= (int)Math.ceil(_alpha * _model.getNumElements())) //if the coverage level is equal or greater than the required coverage then it is solved 
			return true; 
		else 
			return false; 
	}
}
