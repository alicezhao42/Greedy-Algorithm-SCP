package solver;

import util.ElementSet;

public class GreedyCoverageSolver extends GreedySolver{
	
	public GreedyCoverageSolver() {
		_name = "Coverage"; 

	}

	@Override
	public ElementSet nextBestSet() {  
		int _cov = 0; //initialize the starting coverage as 0, so the first set being iterated through will have a higher cover unless it does not cover any useful integers 
		int _max = 0; //variable to store the max coverage of the current best set 
		ElementSet _best = null;  //initialize as null set 
		
		for (ElementSet e: _model.getElementSetiterable()) { //run through all the elementSets in the model 
			if(!_solnSets.contains(e)) { //continue to work with this elementSet only if it hasnt been selected before 
				_cov = 0; //reset the coverage for the next elementSet 
				for(int i: e.getElementIterable()) { //run through the integers in the current elementSet
					if(!_solutionSet.contains(i)) { //count the number of useful integers in this set (add one when the solution set doesnt already contain this integer) 
						_cov += 1;
					}
				} if(_cov > _max) { //replace the best set with set e if it has a higher coverage 
					_best = e; 
					_max = _cov; 
				}
			}
		}
		return _best; //return the best set 
	}

}
