package solver;

import util.ElementSet;

public class GreedyCostSolver extends GreedySolver{
	
	public GreedyCostSolver() {
		_name = "Cost";
	}

	@Override
	public ElementSet nextBestSet() {
		double _lowestCost = Double.MAX_VALUE; //set the initial lowest cost as the maximum value java can hold so that any cost will be lower than this 
		ElementSet _best = null; //set initial set as null 
		
		for (ElementSet e: _model.getElementSetiterable()) { //iterate through all the elementSets in the SCP model 
			if(!_solnSets.contains(e) && e.getCost() < _lowestCost) { //check whether I've used the elementSet and whether it costs less than the lowest cost I have so far 
				for(int i: e.getElementIterable()) { //iterate through the integers in the elementSet list
					if(!_solutionSet.contains(i)) { //if it covers a number that the solution set hasnt already covered then make it the best set
						_best = e; 
						_lowestCost = e.getCost(); 
						break; //stop iterating through the integers once 1 uncovered integer is covered by this elementSet 
					}
				}
			} 
		}
		return _best; //return the best set 
	}

}
