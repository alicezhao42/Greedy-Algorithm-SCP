These are a few samples of files in SCPInstances.zip (available on Quercus).
